function sumarUno() {
    let obj = document.getElementById('contador')
    obj.childNodes[0].nodeValue = parseInt(obj.childNodes[0].nodeValue) + 1
}