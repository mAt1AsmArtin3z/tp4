function entroCasilla(objeto) {
    objeto.style.background = '#ff0'
}

function salioCasilla(objeto) {
    objeto.style.background = '#fff'
}