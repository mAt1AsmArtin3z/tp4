function presionar(objeto) {
    objeto.style.backgroundColor = '#ff0'
}

function levantar(objeto) {
    objeto.style.backgroundColor = '#D4D0C8'
}