function ventanaBienvenida() {
    alert("Bienvenido, acaba de ingresar a https://www.tutorialesprogramacionya.com")
}