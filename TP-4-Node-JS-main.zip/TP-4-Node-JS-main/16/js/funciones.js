function definirAtributo() {
    let reftabla = document.getElementById('tabla1')
    reftabla.setAttribute('border', '5')
}