document.getElementById('enlace').addEventListener('click', () => {
    alert('Gracias por su visita')
})