document.getElementById('comentarios').addEventListener('keydown', (e) => {
    let tecla = e.key
    alert("se presionó la tecla:" + tecla)
})