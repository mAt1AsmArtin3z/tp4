function cambiarFuente(tam) {
    let tit = document.getElementById('comentarios')
    tit.style.fontSize = tam
}