function moverParrafo() {
    let puntero1 = document.getElementById('region1')
    let puntero2 = document.getElementById('region2')
    puntero2.appendChild(puntero1)
}